Make sure to edit config.json
Replace:
"user": "WALLET_ADDRESS",
With your UPX address.

You may obtain a UPX address from https://wallet.uplexa.com

If you are using highend devices or rigs, change fruitypool.com:3333 to fruitypool.com:5555


If you're on Linux and running into depdency issues, install the following:
(Ubuntu)::
sudo apt-get install git build-essential cmake libuv1-dev nvidia-cuda-dev nvidia-cuda-toolkit libmicrohttpd-dev

